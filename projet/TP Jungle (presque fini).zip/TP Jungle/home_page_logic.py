
from db_commands import *


def get_posts(user_id):

    def get_follows(user_id):
        query = """SELECT * FROM Follows
                   WHERE idFollower = ? ;"""
        following = query_db(query=query, args=[user_id], one=False)

        return [x["idFollowing"] for x in following]

    
    
    def get_posts_from_accounts(account_ids):

        query = """SELECT * FROM Posts
                    WHERE id IN """
        query += str(tuple(account_ids)) + ";"
        
        posts = query_db(query=query, one=False)

        return [dict(x) for x in posts]

    
    following = get_follows(user_id)
    posts = get_posts_from_accounts(following)
    return posts



