
import heapq
from fibonacci_heap import *
from binary_heap import *
import random
from graphviz import Digraph


class Network:
    def __init__(self):
        self.adj = {}
        
    def ajouter_sommet(self,s):
        if s not in self.adj:
            self.adj[s] = []
            
    def ajouter_arete(self, s1, s2, dis_1, dis_2):
        self.ajouter_sommet(s1)
        self.ajouter_sommet(s2)
        if s2 not in self.adj[s1]:
            self.adj[s1].append((s2, dis_1))
            self.adj[s2].append((s1, dis_2))
        
    def arete(self,s1,s2):
        return s2 in self.adj[s1]
    
    def supprimer_arete(self, s1, s2):
        if self.arete(s1, s2):
            self.adj[s1].remove(s2)
            self.adj[s2].remove(s1)
    
    def sommets(self):
        return list(self.adj.keys())

    def voisins(self,s):
        return self.adj[s]
    



    def dijkstras_naive(self, start_node, end_node):
        
        file = []
        path = {x:[None, 10**10] for x in self.sommets()}
        visited = {x:False for x in self.sommets()}
        file.append([start_node, 0])
        visited[start_node] = True
        while file:
            file.sort(key=lambda x:x[1])
            node, path_leng = file.pop(0)
            visited[node] = True

            if node == end_node:
                break

            for x in self.voisins(node):
                if not visited[x[0]]:
                    file.append((x[0], path_leng+x[1]))
                    if path_leng+x[1] < path[x[0]][1]:
                        path[x[0]] = [node, path_leng+x[1]]


        return build_path(path, start_node, end_node)

    
                    


    def dijkstras_binary_heap(self, start_node, end_node):
        file = BinHeap()
        path = {x:[None, 10**10] for x in self.sommets()}
        visited = {x:False for x in self.sommets()}
        file.insert((0, start_node))
        visited[start_node] = True
        while file.len() > 0:
            path_leng, node  = file.delMin()
            visited[node] = True

            if node == end_node:
                break
            for x in self.voisins(node):
                if not visited[x[0]]:
                    file.insert((path_leng+x[1], x[0]))
                    if path_leng+x[1] < path[x[0]][1]:
                        path[x[0]] = [node, path_leng+x[1]]


        return build_path(path, start_node, end_node)



    def dijkstras_fibonnacci_heap(self, start_node, end_node):

        file = FibonacciHeap()
        path = {x:[None, 10**10] for x in self.sommets()}
        visited = {x:False for x in self.sommets()}
        file.insert_node(0, start_node)
        visited[start_node] = True
        while file.length() > 0:
            path_leng, node  = file.extract_min()
            visited[node] = True

            if node == end_node:
                break
            for x in self.voisins(node):
                if not visited[x[0]]:
                    file.insert_node(path_leng+x[1], x[0])
                    if path_leng+x[1] < path[x[0]][1]:
                        path[x[0]] = [node, path_leng+x[1]]

        return build_path(path, start_node, end_node)


    def show(self):
        """Représentation graphique avec graphviz"""
        G = Digraph('G', filename='hello.gv')
        for s in self.sommets():
            G.node(s,s)
        for s1 in self.sommets():
            for s2 in self.voisins(s1):
                G.edge(s1, s2[0], label = str(s2[1]))
        G.view()
        return G


def build_path(path, start, end):
    

    path_taken = []

    current = end
    while current is not None:
        path_taken.append(current)
        current = path[current][0]
    
    path_taken.reverse()
    return path_taken




def generate_graph(size, max_connections = 4, max_distance = 10):

    nodes = [x for x in range(size)]
    tree = Network()
    
    for x in nodes:
        potenital_nodes = random.sample(nodes, max_connections)
        for _ in range(random.randint(1, max_connections)):
            distance = random.randint(1, max_distance)
            if x == potenital_nodes[_]:
                potenital_nodes[_] = random.choice(nodes)
            
            if str(x) not in tree.adj or potenital_nodes[_] not in [x[0] for x in tree.voisins(str(x))]:
                tree.ajouter_arete(str(x), str(potenital_nodes[_]), distance, distance)
    
    return tree




    

import time

def compare_speed():

    fibo_time, heap_time, naive_time = 0, 0, 0

        
    for x in range(1):
        graph = generate_graph(50000, 30, 10)

        start = time.time()
        path = graph.dijkstras_fibonnacci_heap("1", str(len(graph.sommets())-1))
        print(path)
        fibo_time =  time.time() - start
        

        start = time.time()
        path = graph.dijkstras_binary_heap("1", str(len(graph.sommets())-1))
        print(path)
        heap_time = time.time() - start
       

        """start = time.time()
        graph.dijkstras_naive("1", str(len(graph.sommets())-1))
        naive_time = time.time() - start"""
        
        print("Fibo Time :", fibo_time, "Heap Time :", heap_time, "Naive Time:", naive_time)

compare_speed()


